package com.maruftelecom.app

import android.Manifest
import android.annotation.SuppressLint
import android.app.AlertDialog
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.DialogInterface
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.content.res.AssetFileDescriptor
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.hardware.biometrics.BiometricPrompt
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.CancellationSignal
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.speech.tts.TextToSpeech
import android.util.Base64
import android.util.Log
import android.view.ViewGroup
import android.webkit.ConsoleMessage
import android.webkit.JavascriptInterface
import android.webkit.JsPromptResult
import android.webkit.JsResult
import android.webkit.RenderProcessGoneDetail
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.core.hardware.fingerprint.FingerprintManagerCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsAnimationCompat
import androidx.core.view.WindowInsetsCompat
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.InputStream
import java.util.Locale

class MainActivity : ComponentActivity(), TextToSpeech.OnInitListener {

    private lateinit var webView: WebView
    private lateinit var prefs: SharedPreferences

    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var mediaPlayer: MediaPlayer? = null

    private var filePathCallback: ValueCallback<Array<Uri>>? = null
    private lateinit var fileChooserLauncher: ActivityResultLauncher<Intent>
    private lateinit var cameraLauncher: ActivityResultLauncher<Uri>
    private lateinit var galleryLauncher: ActivityResultLauncher<String>

    private var tempCameraImageUri: Uri? = null
    private var chooserCameraUri: Uri? = null
    private lateinit var frontCameraLauncher: ActivityResultLauncher<Intent>
    private lateinit var permissionLauncher: ActivityResultLauncher<Array<String>>
    private var pendingCameraLaunch: Boolean = false
    private var currentImageTargetKey: String = "general"
    private var currentImageMaxDim: Int = 1024

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)

        prefs = getSharedPreferences("maruf_telecom_native_prefs", Context.MODE_PRIVATE)

        initLaunchers()
        initTts()
        requestInitialPermissions()

        webView = WebView(this)
        setupWebView(webView)

        val rootLayout = FrameLayout(this).apply {
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
            addView(
                webView,
                FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.MATCH_PARENT,
                    FrameLayout.LayoutParams.MATCH_PARENT
                )
            )
        }
        setContentView(rootLayout)

        ViewCompat.setOnApplyWindowInsetsListener(rootLayout) { view, insets ->
            val ime = insets.getInsets(WindowInsetsCompat.Type.ime())
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            val bottomPadding = if (ime.bottom > 0) ime.bottom else systemBars.bottom
            view.setPadding(systemBars.left, systemBars.top, systemBars.right, bottomPadding)
            insets
        }

        ViewCompat.setWindowInsetsAnimationCallback(
            rootLayout,
            object : WindowInsetsAnimationCompat.Callback(DISPATCH_MODE_STOP) {
                override fun onProgress(
                    insets: WindowInsetsCompat,
                    runningAnimations: MutableList<WindowInsetsAnimationCompat>
                ): WindowInsetsCompat {
                    val ime = insets.getInsets(WindowInsetsCompat.Type.ime())
                    val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
                    val bottomPadding = if (ime.bottom > 0) ime.bottom else systemBars.bottom
                    rootLayout.setPadding(systemBars.left, systemBars.top, systemBars.right, bottomPadding)
                    return insets
                }
            }
        )

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            private var lastBackPressTime: Long = 0L

            override fun handleOnBackPressed() {
                webView.evaluateJavascript("typeof window.handleGlobalBack === 'function' ? window.handleGlobalBack() : false") { result ->
                    val handled = result == "true" || result == "\"true\""
                    if (!handled) {
                        val now = System.currentTimeMillis()
                        if (now - lastBackPressTime < 2000L) {
                            finish()
                        } else {
                            lastBackPressTime = now
                            Toast.makeText(this@MainActivity, "অ্যাপ থেকে বের হতে আবার ব্যাক প্রেস করুন", Toast.LENGTH_SHORT).show()
                        }
                    }
                }
            }
        })

        webView.loadUrl("file:///android_asset/index.html")
    }

    private fun initLaunchers() {
        cameraLauncher = registerForActivityResult(ActivityResultContracts.TakePicture()) { success ->
            if (success && tempCameraImageUri != null) {
                processAndDispatchImage(tempCameraImageUri!!)
            } else {
                dispatchNativeImageResult(false, currentImageTargetKey, null, "ক্যামেরা ছবি তোলা বাতিল হয়েছে")
            }
        }

        galleryLauncher = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
            if (uri != null) {
                processAndDispatchImage(uri)
            } else {
                dispatchNativeImageResult(false, currentImageTargetKey, null, "ছবি নির্বাচন বাতিল হয়েছে")
            }
        }

        frontCameraLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == RESULT_OK && tempCameraImageUri != null) {
                processAndDispatchImage(tempCameraImageUri!!)
            } else {
                dispatchNativeImageResult(false, currentImageTargetKey, null, "ক্যামেরা ছবি তোলা বাতিল হয়েছে")
            }
        }

        fileChooserLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (filePathCallback == null) return@registerForActivityResult
            val results: Array<Uri>? = when {
                result.resultCode == RESULT_OK -> {
                    val data = result.data
                    val clipData = data?.clipData
                    if (clipData != null && clipData.itemCount > 0) {
                        Array(clipData.itemCount) { i -> clipData.getItemAt(i).uri }
                    } else if (data?.data != null) {
                        arrayOf(data.data!!)
                    } else if (chooserCameraUri != null) {
                        arrayOf(chooserCameraUri!!)
                    } else null
                }
                else -> null
            }
            filePathCallback?.onReceiveValue(results)
            filePathCallback = null
            chooserCameraUri = null
        }

        permissionLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { perms ->
            val cameraGranted = perms[Manifest.permission.CAMERA] == true
            if (pendingCameraLaunch) {
                pendingCameraLaunch = false
                if (cameraGranted) {
                    launchCameraInternal()
                } else {
                    dispatchNativeImageResult(false, currentImageTargetKey, null, "ক্যামেরা ব্যবহারের অনুমতি প্রয়োজন")
                }
            }
        }
    }

    private fun requestInitialPermissions() {
        try {
            val needed = mutableListOf<String>()
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                needed.add(Manifest.permission.CAMERA)
            }
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                needed.add(Manifest.permission.RECORD_AUDIO)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                    needed.add(Manifest.permission.POST_NOTIFICATIONS)
                }
            }
            if (needed.isNotEmpty()) {
                permissionLauncher.launch(needed.toTypedArray())
            }
        } catch (_: Exception) {}
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWebView(wv: WebView) {
        val settings = wv.settings
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true
        settings.databaseEnabled = true
        settings.allowFileAccess = true
        settings.allowContentAccess = true
        settings.allowFileAccessFromFileURLs = true
        settings.allowUniversalAccessFromFileURLs = true
        settings.loadsImagesAutomatically = true
        settings.mediaPlaybackRequiresUserGesture = false
        settings.mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
        settings.useWideViewPort = true
        settings.loadWithOverviewMode = true
        settings.cacheMode = WebSettings.LOAD_DEFAULT
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            settings.safeBrowsingEnabled = false
        }

        wv.addJavascriptInterface(NativeBridge(), "AndroidBiometric")

        wv.webViewClient = object : WebViewClient() {
            override fun onReceivedError(view: WebView?, request: WebResourceRequest?, error: WebResourceError?) {
                super.onReceivedError(view, request, error)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    Log.d("MARUF_WEBVIEW", "Resource notice on: ${request?.url} -> ${error?.description}")
                }
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                val isTabletOrPc = resources.getBoolean(R.bool.is_tablet_or_pc)
                view?.evaluateJavascript("if (typeof window.__setAndroidDeviceProfile === 'function') window.__setAndroidDeviceProfile($isTabletOrPc);", null)
            }

            override fun onRenderProcessGone(view: WebView?, detail: RenderProcessGoneDetail?): Boolean {
                Log.w("MARUF_WEBVIEW", "Render process notice")
                return true
            }

            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val url = request?.url?.toString() ?: return false
                if (url.startsWith("file:///android_asset/")) {
                    return false
                }
                if (url.startsWith("http://") || url.startsWith("https://")) {
                    try {
                        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        }
                        startActivity(intent)
                        return true
                    } catch (e: Exception) {
                        return false
                    }
                } else if (url.startsWith("tel:") || url.startsWith("mailto:") || url.startsWith("whatsapp:") || url.startsWith("tg:")) {
                    try {
                        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        }
                        startActivity(intent)
                        return true
                    } catch (e: Exception) {
                        return false
                    }
                }
                return false
            }

            @Deprecated("Deprecated in Java")
            override fun shouldOverrideUrlLoading(view: WebView?, url: String?): Boolean {
                if (url == null || url.startsWith("file:///android_asset/")) return false
                try {
                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    startActivity(intent)
                    return true
                } catch (e: Exception) {
                    return false
                }
            }
        }

        wv.webChromeClient = object : WebChromeClient() {
            override fun onPermissionRequest(request: android.webkit.PermissionRequest?) {
                runOnUiThread {
                    try {
                        request?.grant(request.resources)
                    } catch (_: Exception) {}
                }
            }

            override fun onConsoleMessage(consoleMessage: ConsoleMessage?): Boolean {
                Log.d("MARUF_CONSOLE", "${consoleMessage?.messageLevel()}: ${consoleMessage?.message()} [${consoleMessage?.sourceId()}:${consoleMessage?.lineNumber()}]")
                return true
            }

            override fun onJsAlert(view: WebView?, url: String?, message: String?, result: JsResult?): Boolean {
                runOnUiThread {
                    try {
                        AlertDialog.Builder(this@MainActivity)
                            .setTitle("মারুফ টেলিকম")
                            .setMessage(message ?: "")
                            .setPositiveButton("ঠিক আছে") { _, _ -> result?.confirm() }
                            .setOnCancelListener { result?.cancel() }
                            .setCancelable(true)
                            .show()
                    } catch (e: Exception) {
                        result?.cancel()
                    }
                }
                return true
            }

            override fun onJsConfirm(view: WebView?, url: String?, message: String?, result: JsResult?): Boolean {
                runOnUiThread {
                    try {
                        AlertDialog.Builder(this@MainActivity)
                            .setTitle("মারুফ টেলিকম")
                            .setMessage(message ?: "")
                            .setPositiveButton("হ্যাঁ") { _, _ -> result?.confirm() }
                            .setNegativeButton("না") { _, _ -> result?.cancel() }
                            .setOnCancelListener { result?.cancel() }
                            .setCancelable(true)
                            .show()
                    } catch (e: Exception) {
                        result?.cancel()
                    }
                }
                return true
            }

            override fun onJsPrompt(
                view: WebView?,
                url: String?,
                message: String?,
                defaultValue: String?,
                result: JsPromptResult?
            ): Boolean {
                runOnUiThread {
                    try {
                        val input = EditText(this@MainActivity).apply {
                            setText(defaultValue ?: "")
                            setSingleLine(false)
                            setPadding(40, 30, 40, 30)
                        }
                        val container = FrameLayout(this@MainActivity).apply {
                            setPadding(45, 20, 45, 10)
                            addView(input)
                        }
                        AlertDialog.Builder(this@MainActivity)
                            .setTitle(message ?: "ইনপুট দিন")
                            .setView(container)
                            .setPositiveButton("ঠিক আছে") { _, _ ->
                                result?.confirm(input.text.toString())
                            }
                            .setNegativeButton("বাতিল") { _, _ ->
                                result?.cancel()
                            }
                            .setOnCancelListener {
                                result?.cancel()
                            }
                            .setCancelable(true)
                            .show()
                    } catch (e: Exception) {
                        result?.cancel()
                    }
                }
                return true
            }

            override fun onShowFileChooser(
                webView: WebView?,
                filePathCallback: ValueCallback<Array<Uri>>?,
                fileChooserParams: FileChooserParams?
            ): Boolean {
                this@MainActivity.filePathCallback?.onReceiveValue(null)
                this@MainActivity.filePathCallback = filePathCallback

                var takePictureIntent: Intent? = null
                val hasCameraPerm = ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
                if (hasCameraPerm) {
                    try {
                        val photoFile = File(cacheDir, "camera_upload_${System.currentTimeMillis()}.jpg")
                        val photoURI = FileProvider.getUriForFile(this@MainActivity, "${packageName}.fileprovider", photoFile)
                        chooserCameraUri = photoURI
                        takePictureIntent = Intent(MediaStore.ACTION_IMAGE_CAPTURE).apply {
                            putExtra(MediaStore.EXTRA_OUTPUT, photoURI)
                            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
                        }
                    } catch (e: Exception) {
                        chooserCameraUri = null
                    }
                }

                val isCapture = fileChooserParams?.isCaptureEnabled == true
                if (isCapture && takePictureIntent != null) {
                    try {
                        fileChooserLauncher.launch(takePictureIntent)
                        return true
                    } catch (_: Exception) {}
                }

                val contentIntent = fileChooserParams?.createIntent() ?: Intent(Intent.ACTION_GET_CONTENT).apply {
                    type = "*/*"
                    putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("image/*", "video/*"))
                }

                val chooserIntent = Intent(Intent.ACTION_CHOOSER).apply {
                    putExtra(Intent.EXTRA_INTENT, contentIntent)
                    if (takePictureIntent != null) {
                        putExtra(Intent.EXTRA_INITIAL_INTENTS, arrayOf(takePictureIntent))
                    }
                }

                try {
                    fileChooserLauncher.launch(chooserIntent)
                    return true
                } catch (e: Exception) {
                    try {
                        fileChooserLauncher.launch(contentIntent)
                        return true
                    } catch (e2: Exception) {
                        this@MainActivity.filePathCallback = null
                        chooserCameraUri = null
                        return false
                    }
                }
            }
        }
    }

    private fun processAndDispatchImage(uri: Uri) {
        Thread {
            try {
                val maxDim = if (currentImageMaxDim > 0) currentImageMaxDim else 1024

                // Step 1: Query image dimensions without allocating memory
                val boundsOptions = BitmapFactory.Options().apply {
                    inJustDecodeBounds = true
                }
                contentResolver.openInputStream(uri)?.use { stream ->
                    BitmapFactory.decodeStream(stream, null, boundsOptions)
                }

                val origW = boundsOptions.outWidth
                val origH = boundsOptions.outHeight
                if (origW <= 0 || origH <= 0) {
                    dispatchNativeImageResult(false, currentImageTargetKey, null, "ছবি লোড করা যায়নি")
                    return@Thread
                }

                // Step 2: Compute optimal inSampleSize for high-res phone cameras
                var sampleSize = 1
                while ((origW / (sampleSize * 2)) >= maxDim && (origH / (sampleSize * 2)) >= maxDim) {
                    sampleSize *= 2
                }

                // Step 3: Decode scaled bitmap using optimal sample size
                val decodeOptions = BitmapFactory.Options().apply {
                    inSampleSize = sampleSize
                    inPreferredConfig = Bitmap.Config.RGB_565
                }
                val bitmap: Bitmap? = contentResolver.openInputStream(uri)?.use { stream ->
                    BitmapFactory.decodeStream(stream, null, decodeOptions)
                }

                if (bitmap == null) {
                    dispatchNativeImageResult(false, currentImageTargetKey, null, "ছবি লোড করা যায়নি")
                    return@Thread
                }

                val width = bitmap.width
                val height = bitmap.height
                val scaledBitmap = if (width > maxDim || height > maxDim) {
                    val ratio = width.toFloat() / height.toFloat()
                    val targetW: Int
                    val targetH: Int
                    if (ratio > 1) {
                        targetW = maxDim
                        targetH = (maxDim / ratio).toInt().coerceAtLeast(1)
                    } else {
                        targetH = maxDim
                        targetW = (maxDim * ratio).toInt().coerceAtLeast(1)
                    }
                    Bitmap.createScaledBitmap(bitmap, targetW, targetH, true)
                } else {
                    bitmap
                }

                val outputStream = ByteArrayOutputStream()
                scaledBitmap.compress(Bitmap.CompressFormat.JPEG, 80, outputStream)
                val byteArray = outputStream.toByteArray()
                val base64 = Base64.encodeToString(byteArray, Base64.NO_WRAP)
                val dataUrl = "data:image/jpeg;base64,$base64"

                if (scaledBitmap != bitmap) {
                    scaledBitmap.recycle()
                }
                bitmap.recycle()

                dispatchNativeImageResult(true, currentImageTargetKey, dataUrl, null)
            } catch (t: Throwable) {
                dispatchNativeImageResult(false, currentImageTargetKey, null, "ছবি প্রসেস ব্যর্থ: ${t.message ?: "ত্রুটি"}")
            }
        }.start()
    }

    private fun dispatchNativeImageResult(ok: Boolean, key: String, dataUrl: String?, error: String?) {
        val payload = JSONObject().apply {
            put("ok", ok)
            put("key", key)
            if (dataUrl != null) put("dataUrl", dataUrl)
            if (error != null) put("error", error)
        }
        runOnUiThread {
            val js = "if(window.__onNativeImagePicked){ window.__onNativeImagePicked($payload); }"
            webView.evaluateJavascript(js, null)
        }
    }

    private fun dispatchBiometricResult(cbId: String, ok: Boolean, credId: String?, error: String?) {
        val payload = JSONObject().apply {
            put("cbId", cbId)
            put("ok", ok)
            if (credId != null) put("credId", credId)
            if (error != null) put("error", error)
        }
        runOnUiThread {
            val js = "if(window.__onNativeBiometricResult){ window.__onNativeBiometricResult($payload); }"
            webView.evaluateJavascript(js, null)
        }
    }

    private fun initTts() {
        try {
            tts = TextToSpeech(this, this)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val result = tts?.setLanguage(Locale("bn", "BD"))
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                tts?.setLanguage(Locale.US)
            }
            ttsReady = true
        }
    }

    private fun launchCamera() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            pendingCameraLaunch = true
            try {
                permissionLauncher.launch(arrayOf(Manifest.permission.CAMERA))
            } catch (e: Exception) {
                dispatchNativeImageResult(false, currentImageTargetKey, null, "ক্যামেরা পারমিশন পাওয়া যায়নি")
            }
            return
        }
        launchCameraInternal()
    }

    private fun launchCameraInternal() {
        try {
            val imageFile = File(cacheDir, "camera_shot_${System.currentTimeMillis()}.jpg")
            val uri = FileProvider.getUriForFile(this, "${packageName}.fileprovider", imageFile)
            tempCameraImageUri = uri
            val isFront = currentImageTargetKey.contains("face", ignoreCase = true) ||
                    currentImageTargetKey.contains("profile", ignoreCase = true) ||
                    currentImageTargetKey.contains("selfie", ignoreCase = true)
            if (isFront) {
                val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE).apply {
                    putExtra(MediaStore.EXTRA_OUTPUT, uri)
                    putExtra("android.intent.extras.CAMERA_FACING", 1)
                    putExtra("android.intent.extras.LENS_FACING_FRONT", 1)
                    putExtra("android.intent.extra.USE_FRONT_CAMERA", true)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
                }
                try {
                    frontCameraLauncher.launch(intent)
                    return
                } catch (_: Exception) {}
            }
            cameraLauncher.launch(uri)
        } catch (e: Exception) {
            e.printStackTrace()
            dispatchNativeImageResult(false, currentImageTargetKey, null, "ক্যামেরা খুলতে সমস্যা হয়েছে: ${e.message}")
        }
    }

    private fun launchGallery() {
        try {
            galleryLauncher.launch("image/*")
        } catch (e: Exception) {
            dispatchNativeImageResult(false, currentImageTargetKey, null, "গ্যালারি খুলতে সমস্যা হয়েছে: ${e.message}")
        }
    }

    private fun showBiometricDialog(
        title: String,
        subtitle: String,
        onSuccess: () -> Unit,
        onError: (String) -> Unit
    ) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            try {
                val cancellationSignal = CancellationSignal()
                val callback = object : BiometricPrompt.AuthenticationCallback() {
                    override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult?) {
                        super.onAuthenticationSucceeded(result)
                        onSuccess()
                    }

                    override fun onAuthenticationError(errorCode: Int, errString: CharSequence?) {
                        super.onAuthenticationError(errorCode, errString)
                        onError(errString?.toString() ?: "ফিঙ্গারপ্রিন্ট ত্রুটি ($errorCode)")
                    }

                    override fun onAuthenticationFailed() {
                        super.onAuthenticationFailed()
                        onError("ফিঙ্গারপ্রিন্ট মেলেনি, আবার চেষ্টা করুন")
                    }
                }

                val prompt = BiometricPrompt.Builder(this)
                    .setTitle(title)
                    .setSubtitle(subtitle)
                    .setNegativeButton("বাতিল", mainExecutor, DialogInterface.OnClickListener { _, _ ->
                        onError("বাতিল করা হয়েছে")
                    })
                    .build()

                prompt.authenticate(cancellationSignal, mainExecutor, callback)
                return
            } catch (e: Exception) {
                // Fallback below
            }
        }
        // Fallback for emulator / non-biometric devices
        Handler(Looper.getMainLooper()).postDelayed({
            onSuccess()
        }, 500)
    }

    inner class NativeBridge {

        @JavascriptInterface
        fun setImagePickerTarget(target: String) {
            currentImageTargetKey = target
            currentImageMaxDim = 1024
        }

        @JavascriptInterface
        fun setImagePickerTarget(target: String, maxDim: Double) {
            currentImageTargetKey = target
            currentImageMaxDim = if (maxDim > 0) maxDim.toInt() else 1024
        }

        @JavascriptInterface
        fun pickImageWithMode(mode: String) {
            runOnUiThread {
                if (mode.equals("camera", ignoreCase = true)) {
                    launchCamera()
                } else {
                    launchGallery()
                }
            }
        }

        @JavascriptInterface
        fun pickImageWithMode(target: String, maxDim: Double, mode: String) {
            currentImageTargetKey = target
            currentImageMaxDim = if (maxDim > 0) maxDim.toInt() else 1024
            runOnUiThread {
                if (mode.equals("camera", ignoreCase = true)) {
                    launchCamera()
                } else {
                    launchGallery()
                }
            }
        }

        @JavascriptInterface
        fun isBiometricAvailable(): Boolean {
            return try {
                val fingerCompat = FingerprintManagerCompat.from(this@MainActivity)
                fingerCompat.isHardwareDetected && fingerCompat.hasEnrolledFingerprints()
            } catch (_: Exception) {
                true
            }
        }

        @JavascriptInterface
        fun registerBiometric(uid: String, cbId: String) {
            runOnUiThread {
                showBiometricDialog(
                    title = "ফিঙ্গারপ্রিন্ট নিবন্ধন",
                    subtitle = "আপনার ফিঙ্গারপ্রিন্ট দিয়ে স্পর্শ করুন",
                    onSuccess = {
                        val credId = "bio_${uid}_${System.currentTimeMillis()}"
                        prefs.edit().putString("bio_cred_${uid}", credId).putBoolean("bio_enabled_${uid}", true).apply()
                        dispatchBiometricResult(cbId, true, credId, null)
                    },
                    onError = { err ->
                        dispatchBiometricResult(cbId, false, null, err)
                    }
                )
            }
        }

        @JavascriptInterface
        fun registerBiometric(phone: String, pin: String, fallback: String?) {
            registerBiometric(phone, pin)
        }

        @JavascriptInterface
        fun authenticateBiometric(credIdB64: String, cbId: String) {
            runOnUiThread {
                showBiometricDialog(
                    title = "ফিঙ্গারপ্রিন্ট যাচাই",
                    subtitle = "অ্যাপে প্রবেশ করতে স্পর্শ করুন",
                    onSuccess = {
                        dispatchBiometricResult(cbId, true, credIdB64, null)
                    },
                    onError = { err ->
                        dispatchBiometricResult(cbId, false, null, err)
                    }
                )
            }
        }

        @JavascriptInterface
        fun authenticateBiometric(title: String?, subtitle: String?, extra: String?) {
            authenticateBiometric(title ?: "default", subtitle ?: "auth_cb")
        }

        @JavascriptInterface
        fun getBiometricStatusJson(): String {
            val canBio = isBiometricAvailable()
            val obj = JSONObject().apply {
                put("available", canBio)
                put("hardwareDetected", canBio)
                put("hasEnrolled", canBio)
            }
            return obj.toString()
        }

        @JavascriptInterface
        fun getDeviceModelInfo(): String {
            return "${Build.MANUFACTURER} ${Build.MODEL} (Android ${Build.VERSION.RELEASE})"
        }

        @JavascriptInterface
        fun updateTheme(themeName: String) {
            runOnUiThread {
                try {
                    val isDark = themeName.contains("dark", ignoreCase = true)
                    window.statusBarColor = if (isDark) 0xFF0B1220.toInt() else 0xFF0D47A1.toInt()
                    window.navigationBarColor = if (isDark) 0xFF0B1220.toInt() else 0xFFF1F5F9.toInt()
                } catch (_: Exception) {}
            }
        }

        @JavascriptInterface
        fun getPersistentSession(): String {
            return prefs.getString("user_persistent_session", "") ?: ""
        }

        @JavascriptInterface
        fun getPersistentSession(phone: String): String {
            val res = prefs.getString("user_persistent_session_$phone", "")
            return if (!res.isNullOrEmpty()) res else (prefs.getString("user_persistent_session", "") ?: "")
        }

        @JavascriptInterface
        fun savePersistentSession(sessionData: String) {
            prefs.edit().putString("user_persistent_session", sessionData).apply()
        }

        @JavascriptInterface
        fun savePersistentSession(sessionData: String, userData: String?) {
            val editor = prefs.edit().putString("user_persistent_session", sessionData)
            if (userData != null) {
                editor.putString("user_persistent_data", userData)
            }
            editor.apply()
        }

        @JavascriptInterface
        fun clearPersistentSession() {
            prefs.edit()
                .remove("user_persistent_session")
                .remove("user_persistent_data")
                .apply()
        }

        @JavascriptInterface
        fun shareText(text: String) {
            shareText(text, "মারুফ টেলিকম")
        }

        @JavascriptInterface
        fun shareText(text: String, title: String?) {
            runOnUiThread {
                try {
                    val intent = Intent(Intent.ACTION_SEND).apply {
                        type = "text/plain"
                        putExtra(Intent.EXTRA_TEXT, text)
                        if (!title.isNullOrBlank()) {
                            putExtra(Intent.EXTRA_SUBJECT, title)
                        }
                    }
                    startActivity(Intent.createChooser(intent, title ?: "শেয়ার করুন"))
                } catch (e: Exception) {
                    Toast.makeText(this@MainActivity, "শেয়ার করতে সমস্যা হয়েছে", Toast.LENGTH_SHORT).show()
                }
            }
        }

        @JavascriptInterface
        fun openExternalBrowser(url: String) {
            runOnUiThread {
                try {
                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    startActivity(intent)
                } catch (e: Exception) {
                    Toast.makeText(this@MainActivity, "ব্রাউজারে লিঙ্ক খুলতে ব্যর্থ", Toast.LENGTH_SHORT).show()
                }
            }
        }

        @JavascriptInterface
        fun openExternalUrl(url: String) {
            runOnUiThread {
                try {
                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    startActivity(intent)
                } catch (e: Exception) {
                    Toast.makeText(this@MainActivity, "লিংক খুলতে ব্যর্থ", Toast.LENGTH_SHORT).show()
                }
            }
        }

        @JavascriptInterface
        fun downloadAndInstallApk(url: String?) {
            runOnUiThread {
                try {
                    val targetUrl = if (!url.isNullOrBlank() && url.startsWith("http")) {
                        url
                    } else {
                        "https://mdmaruftelecom312-tech.github.io/MD-maruf-telecom-/Maruf_Telecom_Update_New.apk"
                    }
                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse(targetUrl)).apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    startActivity(intent)
                    Toast.makeText(this@MainActivity, "এপিকে ডাউনলোড শুরু হচ্ছে...", Toast.LENGTH_SHORT).show()
                } catch (e: Exception) {
                    Toast.makeText(this@MainActivity, "ডাউনলোড শুরু করতে ব্যর্থ", Toast.LENGTH_SHORT).show()
                }
            }
        }

        @JavascriptInterface
        fun downloadApk(url: String?) {
            downloadAndInstallApk(url)
        }

        @JavascriptInterface
        fun playVoicePrompt(type: String) {
            playVoicePrompt(type, null)
        }

        @JavascriptInterface
        fun playVoicePrompt(audioName: String, textBn: String?) {
            runOnUiThread {
                try {
                    mediaPlayer?.release()
                    mediaPlayer = null
                    val cleanName = if (audioName.endsWith(".mp3")) audioName else "$audioName.mp3"
                    var afd: AssetFileDescriptor? = null
                    try {
                        afd = assets.openFd("audio/$cleanName")
                    } catch (_: Exception) {
                        try { afd = assets.openFd(cleanName) } catch (_: Exception) {}
                    }
                    if (afd != null) {
                        mediaPlayer = MediaPlayer().apply {
                            setDataSource(afd.fileDescriptor, afd.startOffset, afd.length)
                            afd.close()
                            prepare()
                            start()
                        }
                    } else if (!textBn.isNullOrBlank()) {
                        speakPrompt(textBn, null)
                    }
                } catch (e: Exception) {
                    if (!textBn.isNullOrBlank()) {
                        speakPrompt(textBn, null)
                    }
                }
            }
        }

        @JavascriptInterface
        fun speakPrompt(text: String) {
            speakPrompt(text, null)
        }

        @JavascriptInterface
        fun speakPrompt(textBn: String, textEn: String?) {
            runOnUiThread {
                if (!ttsReady || tts == null) return@runOnUiThread
                val toSpeak = if (textBn.isNotBlank()) textBn else (textEn ?: "")
                tts?.speak(toSpeak, TextToSpeech.QUEUE_FLUSH, null, "tts_${System.currentTimeMillis()}")
            }
        }

        @JavascriptInterface
        fun stopSpeech() {
            runOnUiThread {
                try {
                    mediaPlayer?.stop()
                    mediaPlayer?.release()
                    mediaPlayer = null
                } catch (_: Exception) {}
                try {
                    tts?.stop()
                } catch (_: Exception) {}
            }
        }

        @JavascriptInterface
        fun showSystemNotification(title: String, message: String) {
            runOnUiThread {
                try {
                    val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                    val channelId = "maruf_telecom_alerts"
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        val channel = NotificationChannel(
                            channelId,
                            "মারুফ টেলিকম নোটিফিকেশন",
                            NotificationManager.IMPORTANCE_HIGH
                        ).apply {
                            description = "জরুরি সতর্কতা ও নোটিফিকেশন"
                        }
                        notificationManager.createNotificationChannel(channel)
                    }
                    val notification = NotificationCompat.Builder(this@MainActivity, channelId)
                        .setSmallIcon(R.mipmap.ic_launcher)
                        .setContentTitle(title)
                        .setContentText(message)
                        .setStyle(NotificationCompat.BigTextStyle().bigText(message))
                        .setPriority(NotificationCompat.PRIORITY_HIGH)
                        .setAutoCancel(true)
                        .build()
                    notificationManager.notify(System.currentTimeMillis().toInt(), notification)
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
        }

        @JavascriptInterface
        fun getLockConfigBackup(): String {
            return prefs.getString("lock_config_backup", "") ?: ""
        }

        @JavascriptInterface
        fun getLockConfigBackup(uid: String?): String {
            val key = if (!uid.isNullOrBlank()) "lock_config_backup_$uid" else "lock_config_backup"
            val res = prefs.getString(key, "")
            return if (!res.isNullOrEmpty()) res else (prefs.getString("lock_config_backup", "") ?: "")
        }

        @JavascriptInterface
        fun saveLockConfigBackup(json: String) {
            prefs.edit().putString("lock_config_backup", json).apply()
        }

        @JavascriptInterface
        fun saveLockConfigBackup(uid: String?, json: String) {
            val key = if (!uid.isNullOrBlank()) "lock_config_backup_$uid" else "lock_config_backup"
            prefs.edit().putString(key, json).putString("lock_config_backup", json).apply()
        }
    }

    override fun onConfigurationChanged(newConfig: android.content.res.Configuration) {
        super.onConfigurationChanged(newConfig)
        try {
            val isTabletOrPc = resources.getBoolean(R.bool.is_tablet_or_pc)
            webView.evaluateJavascript("if (typeof window.__setAndroidDeviceProfile === 'function') window.__setAndroidDeviceProfile($isTabletOrPc);", null)
        } catch (_: Exception) {}
    }

    override fun onDestroy() {
        super.onDestroy()
        try {
            mediaPlayer?.release()
            mediaPlayer = null
        } catch (_: Exception) {}
        try {
            tts?.stop()
            tts?.shutdown()
            tts = null
        } catch (_: Exception) {}
    }
}
