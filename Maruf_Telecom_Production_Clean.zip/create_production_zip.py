import os
import zipfile
import shutil

ROOT_DIR = os.path.abspath(os.getcwd())
ARTIFACTS_DIR = os.path.join(ROOT_DIR, ".aistudio", "artifacts", "brain", "c82cb60c-3674-4d20-ad81-0dee9827fa8f")
BUILD_OUTPUTS_DIR = os.path.join(ROOT_DIR, ".build-outputs")
PUBLIC_DIR = os.path.join(ROOT_DIR, "public")

APK_SRC = os.path.join(ROOT_DIR, "app", "build", "outputs", "apk", "debug", "app-debug.apk")

# 1. First sync APK files
if os.path.exists(APK_SRC):
    apk_targets = [
        os.path.join(ROOT_DIR, "Maruf_Telecom_Update_New.apk"),
        os.path.join(ROOT_DIR, "মারুফ টেলিকম আপডেট নিউ এপিকে.apk"),
        os.path.join(BUILD_OUTPUTS_DIR, "app-debug.apk"),
        os.path.join(BUILD_OUTPUTS_DIR, "Maruf_Telecom_Update_New.apk"),
        os.path.join(BUILD_OUTPUTS_DIR, "মারুফ টেলিকম আপডেট নিউ এপিকে.apk"),
        os.path.join(BUILD_OUTPUTS_DIR, "Maruf_Telecom_v3.6.2.apk"),
        os.path.join(PUBLIC_DIR, "Maruf_Telecom_Update_New.apk"),
        os.path.join(PUBLIC_DIR, "Maruf_Telecom_v3.6.2.apk"),
        os.path.join(ARTIFACTS_DIR, "app-debug.apk"),
        os.path.join(ARTIFACTS_DIR, "Maruf_Telecom_Update_New.apk"),
        os.path.join(ARTIFACTS_DIR, "মারুফ টেলিকম আপডেট নিউ এপিকে.apk"),
    ]
    os.makedirs(BUILD_OUTPUTS_DIR, exist_ok=True)
    os.makedirs(PUBLIC_DIR, exist_ok=True)
    os.makedirs(ARTIFACTS_DIR, exist_ok=True)
    for target in apk_targets:
        shutil.copy2(APK_SRC, target)
        print(f"Copied APK to: {target}")

# 2. Build Clean Production ZIP
ZIP_NAME = "Maruf_Telecom_Production_Clean.zip"
ZIP_PATH = os.path.join(ROOT_DIR, ZIP_NAME)

EXCLUDED_DIRS = {
    ".git", ".gradle", "build", ".kotlin", ".aistudio", ".build-outputs",
    "androidTest", "test", "__pycache__", ".idea"
}

EXCLUDED_EXTS = {
    ".apk", ".zip", ".log", ".tmp", ".crdownload"
}

def should_exclude(rel_path):
    parts = rel_path.replace("\\", "/").split("/")
    for part in parts:
        if part in EXCLUDED_DIRS:
            return True
    _, ext = os.path.splitext(rel_path)
    if ext.lower() in EXCLUDED_EXTS:
        return True
    return False

included_count = 0
with zipfile.ZipFile(ZIP_PATH, 'w', zipfile.ZIP_DEFLATED) as zipf:
    for root, dirs, files in os.walk(ROOT_DIR):
        dirs[:] = [d for d in dirs if d not in EXCLUDED_DIRS]
        
        for file in files:
            full_path = os.path.join(root, file)
            rel_path = os.path.relpath(full_path, ROOT_DIR)
            
            if should_exclude(rel_path):
                continue
            
            zipf.write(full_path, rel_path)
            included_count += 1

print(f"Created {ZIP_NAME} with {included_count} clean source files.")

dest_zips = [
    os.path.join(ROOT_DIR, "Maruf_Telecom_Clean_Production.zip"),
    os.path.join(ROOT_DIR, "Maruf_Telecom_Final_Source.zip"),
    os.path.join(BUILD_OUTPUTS_DIR, "Maruf_Telecom_Production_Clean.zip"),
    os.path.join(BUILD_OUTPUTS_DIR, "Maruf_Telecom_Clean_Production.zip"),
    os.path.join(BUILD_OUTPUTS_DIR, "Maruf_Telecom_Final_Source.zip"),
    os.path.join(PUBLIC_DIR, "Maruf_Telecom_Production_Clean.zip"),
    os.path.join(PUBLIC_DIR, "Maruf_Telecom_Clean_Production.zip"),
    os.path.join(PUBLIC_DIR, "Maruf_Telecom_Final_Source.zip"),
    os.path.join(ARTIFACTS_DIR, "Maruf_Telecom_Production_Clean.zip"),
    os.path.join(ARTIFACTS_DIR, "Maruf_Telecom_Clean_Production.zip"),
    os.path.join(ARTIFACTS_DIR, "Maruf_Telecom_Final_Source.zip"),
]

for dest in dest_zips:
    os.makedirs(os.path.dirname(dest), exist_ok=True)
    shutil.copy2(ZIP_PATH, dest)
    print(f"Copied ZIP to: {dest}")
