
import http from "node:http";
import fs from "node:fs";
import path from "node:path";

const PORT = 3000;
const ASSETS_DIR = path.resolve("app/src/main/assets");
const BUILD_OUTPUTS = path.resolve(".build-outputs");

const MIME_TYPES = {
  ".html": "text/html; charset=utf-8",
  ".js": "application/javascript; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".png": "image/png",
  ".jpg": "image/jpeg",
  ".jpeg": "image/jpeg",
  ".svg": "image/svg+xml",
  ".ico": "image/x-icon",
  ".apk": "application/vnd.android.package-archive",
  ".zip": "application/zip"
};

const server = http.createServer((req, res) => {
  const urlPath = decodeURIComponent(req.url.split("?")[0]);
  
  // ZIP source code download route
  if (urlPath.endsWith(".zip") || urlPath === "/download-zip" || urlPath === "/download-source") {
    const zipCandidates = [
      path.resolve("Maruf_Telecom_Final_Source.zip"),
      path.join(BUILD_OUTPUTS, "Maruf_Telecom_Final_Source.zip"),
      path.join(ASSETS_DIR, "Maruf_Telecom_Final_Source.zip")
    ];
    for (const zp of zipCandidates) {
      if (fs.existsSync(zp)) {
        const stat = fs.statSync(zp);
        res.writeHead(200, {
          "Content-Type": "application/zip",
          "Content-Length": stat.size,
          "Content-Disposition": "attachment; filename=\"Maruf_Telecom_Final_Source.zip\""
        });
        return fs.createReadStream(zp).pipe(res);
      }
    }
  }

  // APK download routes
  if (urlPath.endsWith(".apk") || urlPath === "/download-apk") {
    const candidates = [
      path.join(BUILD_OUTPUTS, "Maruf_Telecom_Update_New.apk"),
      path.join(BUILD_OUTPUTS, "মারুফ টেলিকম আপডেট নিউ এপিকে.apk"),
      path.join(BUILD_OUTPUTS, "app-debug.apk"),
      path.resolve("app/build/outputs/apk/debug/app-debug.apk"),
      path.resolve("Maruf_Telecom_Update_New.apk"),
      path.resolve("মারুফ টেলিকম আপডেট নিউ এপিকে.apk")
    ];
    for (const apkPath of candidates) {
      if (fs.existsSync(apkPath)) {
        const stat = fs.statSync(apkPath);
        res.writeHead(200, {
          "Content-Type": "application/vnd.android.package-archive",
          "Content-Length": stat.size,
          "Content-Disposition": "attachment; filename=\"Maruf_Telecom_Update_New.apk\""
        });
        return fs.createReadStream(apkPath).pipe(res);
      }
    }
  }

  // File resolution in assets
  let filePath = path.join(ASSETS_DIR, urlPath === "/" ? "index.html" : urlPath);

  // If path does not exist, fall back to index.html for SPA routing
  if (!fs.existsSync(filePath) || fs.statSync(filePath).isDirectory()) {
    filePath = path.join(ASSETS_DIR, "index.html");
  }

  const ext = path.extname(filePath).toLowerCase();
  const contentType = MIME_TYPES[ext] || "application/octet-stream";

  fs.readFile(filePath, (err, data) => {
    if (err) {
      res.writeHead(404, { "Content-Type": "text/plain" });
      res.end("Not Found");
      return;
    }
    res.writeHead(200, { "Content-Type": contentType });
    res.end(data);
  });
});

server.listen(PORT, "0.0.0.0", () => {
  console.log(`Web server listening on http://0.0.0.0:${PORT}`);
});
