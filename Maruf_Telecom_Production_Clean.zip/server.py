import http.server
import socketserver
import os
import urllib.parse

PORT = 3000
WORKSPACE_DIR = os.path.dirname(os.path.abspath(__file__))
ASSETS_DIR = os.path.join(WORKSPACE_DIR, "app", "src", "main", "assets")

class CustomHandler(http.server.SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=ASSETS_DIR, **kwargs)

    def _serve_apk(self, send_body=True):
        parsed = urllib.parse.urlparse(self.path)
        path_clean = parsed.path.lstrip('/')
        if path_clean.endswith('.apk') or 'Maruf' in path_clean:
            apk_candidates = [
                os.path.join(WORKSPACE_DIR, "Maruf_Telecom_Update_New.apk"),
                os.path.join(WORKSPACE_DIR, ".build-outputs", "app-debug.apk"),
                os.path.join(WORKSPACE_DIR, "app", "build", "outputs", "apk", "debug", "app-debug.apk")
            ]
            for apk_path in apk_candidates:
                if os.path.isfile(apk_path):
                    self.send_response(200)
                    self.send_header("Content-Type", "application/vnd.android.package-archive")
                    self.send_header("Content-Disposition", 'attachment; filename="Maruf_Telecom_Update_New.apk"')
                    self.send_header("Content-Length", str(os.path.getsize(apk_path)))
                    self.send_header("Access-Control-Allow-Origin", "*")
                    self.send_header("Cache-Control", "no-cache")
                    self.end_headers()
                    if send_body:
                        with open(apk_path, "rb") as f:
                            while chunk := f.read(65536):
                                self.wfile.write(chunk)
                    return True
        return False

    def do_HEAD(self):
        if self._serve_apk(send_body=False):
            return
        return super().do_HEAD()

    def do_GET(self):
        if self._serve_apk(send_body=True):
            return
        return super().do_GET()

    def end_headers(self):
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Cache-Control", "no-cache")
        super().end_headers()

if __name__ == "__main__":
    socketserver.TCPServer.allow_reuse_address = True
    with socketserver.TCPServer(("", PORT), CustomHandler) as httpd:
        print(f"Serving on port {PORT}...")
        httpd.serve_forever()
